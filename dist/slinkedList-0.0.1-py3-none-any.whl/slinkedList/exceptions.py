""" Exceptions for algorithms"""


class incorrect_type(ValueError):
    """Vlaue error for cleantext
    """