stype=(int,float,str,complex)
mtype=(list,tuple,set)