import slinkedList as ll

# main method

# creating LinkedList
# m= ll.SingleLinkedList(data=[1,2,3,4])
# n= ll.SingleLinkedList(data=[5,4,6,7])
# r = ll.SingleLinkedList()


# # __add__
# m= ll.SingleLinkedList(data=[1,2,3,4,"hi",complex(2,3)])
# n= ll.SingleLinkedList(data=[5,6,7,"hi",complex(1,2)])
# assert m+n==ll.SingleLinkedList(data=[1,2,3,4,"hi",complex(2,3),5,6,7,"hi",complex(1,2)])

#__-add__
# m= ll.SingleLinkedList(data=[1,2,3,4])
# n= ll.SingleLinkedList(data=[5,6,7,8])
# del m[2]
# print(m)

# print(p.sum()) 
#print(m.removeAtEnd())
#print(n.removeAtPosition([0,2]))
#print(r.removeAtStart())
#print(m.toString('_'))
#print(n.toString('.'))
#print(m.dataCount((2,3,4,5)))
#print(m.toList())
#print(n.toSet())
#print(m.reverse())
#print(m.removeDuplicates())
#print(m.equal(n))
#print(r.equal())
#print(r.search(0))
#print(n.search('-'))
#print(n.sorted()) #'>' not supported between instances of 'str' and 'int'

# print(r)
#print(m.remove_Max())
#print(m.remove_Min(False))
#print(m.push([8,9]))
#print(m.popEnd(2))
#print(m.clear())
#print(m.Min())
#print(n.Min()) # '<' not supported between instances of 'str' and 'int'
#print(n.Max()) # '<' not supported between instances of 'str' and 'int'
#print(n.removeItem(10))
# print(n)
# #print(m.removeItem((2,3,4,5)))
# print(m)
#print(m,n,p,r)
#assert m.countItem(10) == 0
#print(r.isEmpty())
#print(n.replace(10,'a'))
#print(n)
#print(r.headNode())
#print(r.iterNodes())
#print(r.nodeAtPosition(3))
#print(n.sum(1,3,1)) # user defined error raised 

#print(m.sum(start=1,step=1))
#
#print(m.sum())
#print(m.mean())
#print(m.median())
#print(m.mode())

#print(m.slice(2,4,1))
#print(r.slice())
#print(m.isUniqueType())
#print(m.doesHaveType(int))
#print(n.doesHaveType((int,str)))

#print(m.addToStart(['abc','a','c']))
#print(m)
#print(m.addToEnd(n))

#print(n.addToStart(('a','b','c')))
#print(n.addToStart({1:2,3:4}))
#print(n)

#print(r.insertPos(0)) #'<' not supported between instances of 'NoneType' and 'int'
#print(r.insertPos(node=0))
#print(r.insertPos(data=0)) #'<' not supported between instances of 'NoneType' and 'int'
#print(r.insertPos(index=0))
#
#print(r.isNodeIn(4))
#print(m.isNodeIn(4))

#print(m.datanode(2))
#print(r.datanode(3))
#print(m.insertAfter(2,10))
#print(m.insertAfter(2,['a','b'])) #error

#print(m.length())
#print(r.length())
#print(m.index((2,3,4)))

#print(m.atIndex([2])) #'>=' not supported between instances of 'list' and 'int'
#print(m)
#print(m.replace(3,10,False))
#print(m)
#print(m.replaceOf(3,10,False,2))
#print(m)

#print(m.count())

